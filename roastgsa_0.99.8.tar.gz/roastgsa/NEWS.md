# roastgsa (development version)
* R package for gene set analysis.
* Competitive and self-contained testing using rotations 
to represent the null distribution.
* Several test statistics are available, with maxmean 
being our preferred option.
* Visualization tools for the roastgsa results are provided.
